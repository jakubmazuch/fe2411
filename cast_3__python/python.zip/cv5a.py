def pocetMezer(text):
    return text.count(" ")


print(pocetMezer("Poslední Mohykán je historicko-dobrodružný román, mnohými považován za nejlepší indiánku všech dob. Příběh se odehrává v několika srpnových dnech roku 1757 za sedmileté války mezi Francouzi a Angličany (1756–1763), jejímž důsledkem byl konec koloniálního panství Francouzů na území dnešních Spojených států amerických a Kanady."))
