def pocetSlov(text):
    return len(text.split())


vstup = input("Zadejte text: ")
print(pocetSlov(vstup))
