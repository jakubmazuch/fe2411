def delitelnost(x, y):
    return x % y == 0


cislo1 = int(input("Zadejte první číslo: "))
cislo2 = int(input("Zadejte další číslo: "))

print(delitelnost(cislo1, cislo2))
