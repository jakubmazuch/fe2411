x = int(input("Zadej číslo: "))
n = int(input("Zadej mocninu: "))
print(x**n)
