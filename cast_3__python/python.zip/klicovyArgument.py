def mocnina(cislo, exp=2):  # poziční argument (cislo); klíčový argument (exp)
    cislo = cislo ** exp
    return cislo


print(mocnina(5, 5))
