def mocnina(x):
    return x**2


print(mocnina(5))
