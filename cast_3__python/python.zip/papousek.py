a = input("Napiš něco: ")
print(a)
