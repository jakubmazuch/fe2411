for a in range(0, 10):
    pass

print("Hotovo")
