a = int(input("Zadej číslo: "))
if a > 0:
    print("Číslo", a, "je kladné.")
elif a < 0:
    print("Číslo", a, "je záporné.")
else:
    print("Číslo je nula.")
