veta = "JavaScript je nejlepší programovací jazyk na světě!"
veta = veta.replace("JavaScript", "Python")
print(veta.upper())
print(veta.lower())
