for i in range(1, 11):
    print(i, end="|")
print()

for i in range(1, 21, 3):
    print(i, end="|")
print()

for i in range(-10, 21, 4):
    print(i, end="|")
print()

for i in range(10, 0, -1):
    print(i, end="|")
