print("Zadejte číslo: ")
vstupA = input()
print("Zadali jste text: " + vstupA)
cistyA = vstupA.strip()
print("Zadali jste text: ", cistyA)

cisloB = int(8)

cisloA = int(cistyA)
print("Zadali jste číslo: ", cisloA)
print("Součet čísel: ", cisloA + cisloB)
