def delitelnost(x):
    return x % 2 == 0


cislo = int(input("Zadej číslo: "))
print(delitelnost(cislo))
