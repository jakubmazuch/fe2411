muz = True
nazevPohlavi = ""
if muz:
    nazevPohlavi = "muž"
else:
    nazevPohlavi = "žena"
print(nazevPohlavi)
