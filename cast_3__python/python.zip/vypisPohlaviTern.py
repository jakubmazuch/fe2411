muz = True
nazevPohlavi = "muz" if (muz) else "žena"
print(nazevPohlavi)
