cislo = 0
while cislo <= 10:
    print(cislo, end="|")
    cislo += 1

i = 10
while i >= 0:
    print(i, end=", ")
    i -= 1
